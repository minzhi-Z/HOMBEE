function $(...args){
   return document.querySelectorAll(...args)
}
window.onload=function(){
  let addBtn=$("#main>.btn>input")[0];
  addBtn.onclick=function(){
     window.location.href="qiyekehu-add-dingdan.html"
  }
}