window.onload=function(){
   let mengban=document.getElementById("mengban");
   let close=document.querySelector(".msg>h3>.close");
   let addZubao=document.querySelectorAll(".item-msg>p .add");
   Array.from(addZubao).forEach(item=>{
      item.onclick=function(){
         mengban.style.display="block";
      }
   })
   close.onclick=function(){
      mengban.style.display="none";
   }

}